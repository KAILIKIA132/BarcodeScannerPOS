package com.arodi.powergas.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.arodi.powergas.R;
import com.arodi.powergas.adapters.ExpenditureAdapter;
import com.arodi.powergas.adapters.StockAdapter;
import com.arodi.powergas.api.BaseURL;
import com.arodi.powergas.database.Database;
import com.arodi.powergas.databinding.ActivityStockBinding;
import com.arodi.powergas.helpers.NetworkState;
import com.arodi.powergas.models.ExpenditureModel;
import com.arodi.powergas.models.ProductModel;
import com.arodi.powergas.models.ProductQuantity;
import com.arodi.powergas.models.StockModel;
import com.arodi.powergas.session.SessionManager;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class StockActivity extends AppCompatActivity {
    ActivityStockBinding binding;
    StockAdapter adapter;
    ArrayList<StockModel> stockModel = new ArrayList<>();
    HashMap<String, String> user;
    int day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_stock);
        user = new SessionManager(StockActivity.this).getLoginDetails();
        binding.back.setOnClickListener(view -> onBackPressed());
        binding.RecyclerView.setHasFixedSize(true);
        binding.RecyclerView.setLayoutManager(new LinearLayoutManager(StockActivity.this));
        binding.Refresh.setColorSchemeColors(Color.BLUE, Color.RED, Color.BLUE, Color.GREEN);
        binding.Refresh.setOnRefreshListener(() -> {
                    if (NetworkState.getInstance(StockActivity.this).isConnected()) {
                        getProducts();
                    }
                }
        );

        populateStock();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getProducts();
    }

    private void fetchProductQuantity() {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(BaseURL.SERVER_URL + "products/productsEndpoint.php?action=fetch_product_quantity&vehicle_id=" + user.get(SessionManager.KEY_VEHICLE_ID) + "&distributor_id=" + user.get(SessionManager.KEY_DISTRIBUTOR_ID))
                .method("GET", null)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    binding.Refresh.setRefreshing(false);
                    System.out.println("errorrr" + e.toString());
                });
            }

            @Override
            public void onResponse(Call call, Response response) {
                runOnUiThread(() -> {
                    binding.Refresh.setRefreshing(false);
                    try {
                        JSONArray jsonArray = new JSONArray(response.body().string());
                        System.out.println("jsonObjuyrtygtyectdfdfdiighgghhddddiii" + jsonArray);

                        new Database(StockActivity.this.getBaseContext()).clear_product_quantity();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            ProductQuantity model = new ProductQuantity(
                                    jsonObject.getString("product_id"),
                                    jsonObject.getString("quantity"));

                            new Database(getBaseContext()).create_product_quantity(model);
                        }
                        populateStock();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                });

            }
        });
    }

    private void getProducts() {
        binding.Refresh.setRefreshing(true);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        String dayOfWeek = calendar.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault());
        System.out.println("dayofweek" + dayOfWeek);

        if (dayOfWeek != null) {
            switch (dayOfWeek) {
                case "Monday":
                    day = 1;
                    break;
                case "Tuesday":
                    day = 2;
                    break;
                case "Wednesday":
                    day = 3;
                    break;
                case "Thursday":
                    day = 4;
                    break;
                case "Friday":
                    day = 5;
                    break;
                case "Saturday":
                    day = 6;
                    break;
                case "Sunday":
                    day = 7;
                    break;
            }
        }
        OkHttpClient client = new OkHttpClient().newBuilder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(BaseURL.SERVER_URL + "products/productsEndpoint.php?action=fetch_products&vehicle_id=" + user.get(SessionManager.KEY_VEHICLE_ID) + "&day=" + day + "&distributor_id=" + user.get(SessionManager.KEY_DISTRIBUTOR_ID))
                .method("GET", null)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    System.out.println("errorrr" + e.toString());
                    binding.Refresh.setRefreshing(false);
                });
            }

            @Override
            public void onResponse(Call call, Response response) {
                runOnUiThread(() -> {
                    try {
                        JSONArray jsonArray = new JSONArray(response.body().string());
                        System.out.println("jsonObjectiiddddiii" + jsonArray);

                        new Database(StockActivity.this.getBaseContext()).clear_products();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            ProductModel model = new ProductModel(
                                    jsonObject.getString("product_id"),
                                    jsonObject.getString("product_code"),
                                    jsonObject.getString("product_name"),
                                    jsonObject.getString("price"),
                                    jsonObject.getString("quantity"),
                                    jsonObject.getString("plate_no"),
                                    jsonObject.getString("discount_enabled"),
                                    jsonObject.getString("target"),
                                    jsonObject.getString("portion1"),
                                    jsonObject.getString("portion1qty"),
                                    jsonObject.getString("portion2"),
                                    jsonObject.getString("portion2qty"),
                                    jsonObject.getString("portion3"),
                                    jsonObject.getString("portion3qty"),
                                    jsonObject.getString("portion4"),
                                    jsonObject.getString("portion4qty"),
                                    jsonObject.getString("portion5"),
                                    jsonObject.getString("portion5qty"),
                                    jsonObject.getString("isKitchen"));

                            new Database(getBaseContext()).create_product(model);
                        }
                        fetchProductQuantity();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                });

            }
        });
    }

    private void initAdapter() {
        adapter = new StockAdapter(StockActivity.this, stockModel);
        adapter.notifyDataSetChanged();
        binding.RecyclerView.setAdapter(adapter);

        int total = 0;
        try {
            for (StockModel model : stockModel) {
                total += Integer.parseInt(model.getStock());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        if (user.get(SessionManager.KEY_ENABLE_STOCK).equals("1")) {
            binding.TotalItems.setText(String.valueOf(total) + " Items");
        }else {
            binding.TotalItems.setText("null Items");
        }

        if (stockModel.size() == 0) {
            binding.RelNo.setVisibility(View.VISIBLE);
            binding.Head.setVisibility(View.GONE);
        } else {
            binding.RelNo.setVisibility(View.GONE);
            binding.Head.setVisibility(View.VISIBLE);
        }
    }

    public void populateStock() {
        stockModel.clear();
        stockModel = (ArrayList<StockModel>) new Database(StockActivity.this).fetch_stock();
        initAdapter();
    }
}