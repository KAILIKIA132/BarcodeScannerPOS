package com.arodi.powergas.interfaces;

public interface shopInterface {
    void shopData();
}
