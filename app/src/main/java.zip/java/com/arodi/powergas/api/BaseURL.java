package com.arodi.powergas.api;

public class BaseURL {
    public static String SERVER_URL = "http://192.168.1.227/api_powergas/";
//    public static String SERVER_URL = "https://powergas.techsavanna.co.ke/powergas_app/";
//    public static String ROUTE_URL = "https://powergas.techsavanna.co.ke/powergas_app/";
    public static String ROUTE_URL = "http://192.168.1.227/api_powergas/";

}
