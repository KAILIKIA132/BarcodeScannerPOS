package com.arodi.powergas.interfaces;

public interface methodInterface {
    void putPreference();
}
